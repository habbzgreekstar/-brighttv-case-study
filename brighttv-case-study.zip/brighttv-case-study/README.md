# BrightTV Viewership Analytics — Case Study

CVM case study: analyse BrightTV subscriber and viewership data in Databricks to recommend how to grow the subscription base.

## Contents

- `sql/01_create_schema_and_tables.sql` — creates the `brighttv` schema, `user_profiles` and `viewership` Delta tables, and loads the CSVs via `COPY INTO`.
- `sql/02_analysis_queries.sql` — creates a SAST (UTC+2) view of the viewership data and runs the queries behind every insight in `ANSWERS.md`.
- `data/user_profiles.csv`, `data/viewership.csv` — source data (from the original case-study dataset).
- `ANSWERS.md` — written answers to all four case-study questions, backed by the query results.

## How to reproduce in Databricks

1. Upload `data/user_profiles.csv` and `data/viewership.csv` to a Unity Catalog Volume (e.g. `/Volumes/main/brighttv/raw_files/`).
2. Run `sql/01_create_schema_and_tables.sql` in a Databricks SQL editor or notebook.
3. Run `sql/02_analysis_queries.sql` to reproduce the analysis.
4. See `ANSWERS.md` for the write-up.
