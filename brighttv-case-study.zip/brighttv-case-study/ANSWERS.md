# BrightTV Case Study — Answers

Dataset: 5,375 subscriber profiles, 10,000 viewing sessions (1 Jan – 31 Mar 2016, UTC → converted to SAST/UTC+2).

## 1. User and usage trends

**By day of week** — consumption rises steadily through the week and peaks on the weekend:

| Day | Sessions | Watch hours | Avg session (min) |
|---|---|---|---|
| Monday (lowest) | 957 | 115 | 7.2 |
| Tuesday | 1,322 | 199 | — |
| Sunday | 1,419 | 195 | — |
| Thursday | 1,441 | 232 | — |
| Wednesday | 1,553 | 234 | — |
| Saturday (highest) | 1,633 | 296 | 10.9 |
| Friday | 1,675 | 252 | — |

Monday has 42% fewer sessions than Friday, and sessions on Monday are also ~34% shorter on average — it's the clear low point of the week.

**By time of day** — usage is a single evening-peaked curve: it bottoms out in the early hours (2 AM–5 AM, <100 sessions/hr) and climbs through the day to a prime-time peak between 15:00–19:00 (620–650 sessions/hr), which is when people are home from work/school.

**By subscriber profile:**
- **Province**: Gauteng (3,654 sessions) and Western Cape (1,845) dominate — together over half of all activity, roughly tracking population/urbanisation.
- **Gender**: Viewership skews heavily male (8,761 vs 977 female sessions) — a ~9:1 split that's worth validating against the true subscriber gender mix, since it may reflect who's *watching* on a shared household account rather than who *subscribes*.
- **Age**: 25–34 is the core audience (4,148 sessions, 41% of total), followed by 35–44. Under-18 and 55+ are the smallest segments.
- **Reach**: only 4,386 of 5,375 subscribers (82%) generated a session in the period — 989 subscribers (18%) show zero recorded viewing, a churn/re-engagement risk worth flagging to CVM.

## 2. What factors influence consumption?

- **Day of week** — weekday vs weekend behaviour is the strongest pattern (Monday lull, Fri–Sat peak).
- **Time of day** — a clear prime-time window (15:00–19:00 SAST); anything scheduled or promoted outside this window will underperform.
- **Content genre/type** — sport dominates: Supersport Live Events and the ICC Cricket World Cup 2011 are the two most-watched properties overall, and Cricket World Cup sessions run far longer on average (~17 min vs ~9 min site-wide) — live sport drives both reach and sustained watch time.
- **Demographics** — usage concentrates in Gauteng/Western Cape and the 25–44 age band, so content and promotion aimed at that segment will have the widest reach.

## 3. What content to push on low-consumption days

Monday's own top channels (Channel O, Trace TV, Cartoon Network, Africa Magic) are lighter entertainment/music/kids content — the audience that *is* online on Mondays is watching low-commitment, easy-viewing content, not appointment TV.

Recommendations:
- **Schedule a marquee live-sport or event slot on Monday nights** (Supersport / marquee football or cricket fixtures) in the 15:00–19:00 window — the format that drives BrightTV's longest sessions and highest engagement elsewhere in the week, deliberately placed where it's currently absent.
- **Push music/entertainment premieres (Channel O, Trace TV) earlier in the Monday evening** to capture the audience that's already there, then use it as a lead-in to draw viewers toward higher-value content later in the night.
- **Kids' programming block (Cartoon Network/Boomerang) in the Monday after-school slot (15:00–17:00)** — this is already a Monday strength; reinforce it with promoted new-episode drops to convert casual viewing into habitual Monday viewing.
- **Use push notifications / app prompts timed to Monday 12:00–14:00** (the deepest trough) advertising the evening's content, to pull the day's viewing later where retention is higher.

## 4. Initiatives to grow the subscriber base

- **Close the 18% engagement gap**: nearly 1 in 5 subscribers has no recorded session — a targeted re-engagement campaign (free preview, personalised recommendation email/push) aimed at this cohort is likely the highest-ROI lever, since these are already-paying/registered users, not net-new acquisition.
- **Double down on live sport as the acquisition hook**: sport clearly drives the longest, stickiest sessions — bundling or promoting major fixtures (football, cricket) as the entry point for new subscribers, especially around big tournaments, should convert well given the existing viewing pattern.
- **Expand reach outside Gauteng/Western Cape**: provinces like Northern Cape, North West and Free State are under-represented relative to national population share — localized marketing, partnerships, or province-specific content bundles could unlock underpenetrated markets.
- **Grow the female and older (45+) audience**: both are currently under-represented in viewership. Content genres or bundles (e.g. drama, lifestyle, family content) targeted at these segments, tested and measured the same way as the current sport-led strategy, could diversify and grow the base rather than only deepening engagement with the existing core (male, 25–44) audience.
- **Weekday retention program**: since Monday–Tuesday is the soft spot, a "weekday rewards"/loyalty mechanic (bonus content, discounts) tied to weekday viewing could flatten the week's consumption curve and increase overall watch time without needing new content spend.

---
*Notes/assumptions: `RecordDateUTC` converted to SAST as UTC+2 (South Africa has no daylight saving). Session count is used as the primary volume metric per the brief ("1 record per session"). Some `Race`/`Gender` values are missing in source data (NaN) and were excluded from those specific breakdowns rather than imputed.*
