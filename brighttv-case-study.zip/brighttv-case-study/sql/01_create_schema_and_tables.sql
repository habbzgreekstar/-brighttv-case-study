-- ============================================================
-- BrightTV Case Study — Schema & Table Setup (Databricks SQL)
-- ============================================================

-- 1. Create the schema (database) for this case study
CREATE SCHEMA IF NOT EXISTS brighttv
COMMENT 'BrightTV viewership analytics case study';

USE SCHEMA brighttv;

-- 2. User profiles table
CREATE TABLE IF NOT EXISTS brighttv.user_profiles (
    UserID              BIGINT,
    Name                STRING,
    Surname             STRING,
    Email               STRING,
    Gender              STRING,
    Race                STRING,
    Age                 INT,
    Province            STRING,
    SocialMediaHandle   STRING
)
USING DELTA
COMMENT 'BrightTV subscriber profile data';

-- 3. Viewership (session-level) table
--    One row = one viewing session for one subscriber.
--    RecordDateUTC is stored as supplied (UTC) — converted to SA time (UTC+2) in queries below.
CREATE TABLE IF NOT EXISTS brighttv.viewership (
    UserID          BIGINT,
    Channel         STRING,
    RecordDateUTC   TIMESTAMP,
    Duration        STRING      -- stored as HH:MM:SS, cast to seconds in analysis queries
)
USING DELTA
COMMENT 'BrightTV per-session viewership transactions (UTC timestamps)';

-- ============================================================
-- 4. Load data
-- ============================================================
-- Upload user_profiles.csv and viewership.csv to a Unity Catalog Volume
-- (or DBFS) first, e.g. /Volumes/main/brighttv/raw_files/, then run:

COPY INTO brighttv.user_profiles
FROM '/Volumes/main/brighttv/raw_files/user_profiles.csv'
FILEFORMAT = CSV
FORMAT_OPTIONS ('header' = 'true', 'inferSchema' = 'true')
COPY_OPTIONS ('mergeSchema' = 'true');

COPY INTO brighttv.viewership
FROM '/Volumes/main/brighttv/raw_files/viewership.csv'
FILEFORMAT = CSV
FORMAT_OPTIONS ('header' = 'true', 'inferSchema' = 'true')
COPY_OPTIONS ('mergeSchema' = 'true');

-- Sanity checks
SELECT COUNT(*) AS user_profile_rows FROM brighttv.user_profiles;
SELECT COUNT(*) AS viewership_rows   FROM brighttv.viewership;
