-- ============================================================
-- BrightTV Case Study — Analysis Queries (Databricks SQL)
-- ============================================================
USE SCHEMA brighttv;

-- ------------------------------------------------------------
-- Base view: sessions in SA local time (UTC+2, no DST), with
-- a numeric duration and joined subscriber attributes.
-- ------------------------------------------------------------
CREATE OR REPLACE VIEW brighttv.viewership_sast AS
SELECT
    v.UserID,
    v.Channel,
    v.RecordDateUTC,
    v.RecordDateUTC + INTERVAL 2 HOURS                                   AS RecordDateSAST,
    date_format(v.RecordDateUTC + INTERVAL 2 HOURS, 'EEEE')               AS DayOfWeek,
    hour(v.RecordDateUTC + INTERVAL 2 HOURS)                              AS HourOfDay,
    (CAST(split(v.Duration, ':')[0] AS INT) * 3600
     + CAST(split(v.Duration, ':')[1] AS INT) * 60
     + CAST(split(v.Duration, ':')[2] AS INT))                            AS DurationSeconds,
    p.Gender, p.Race, p.Age, p.Province
FROM brighttv.viewership v
LEFT JOIN brighttv.user_profiles p
    ON v.UserID = p.UserID;

-- ------------------------------------------------------------
-- Q1a. Usage trends — sessions & watch time by day of week
-- ------------------------------------------------------------
SELECT DayOfWeek,
       COUNT(*)                       AS sessions,
       ROUND(SUM(DurationSeconds)/3600, 1) AS watch_hours,
       ROUND(AVG(DurationSeconds)/60, 1)   AS avg_session_minutes
FROM brighttv.viewership_sast
GROUP BY DayOfWeek
ORDER BY sessions;

-- Q1b. Usage trends — sessions by hour of day (SAST)
SELECT HourOfDay,
       COUNT(*) AS sessions,
       ROUND(SUM(DurationSeconds)/3600, 1) AS watch_hours
FROM brighttv.viewership_sast
GROUP BY HourOfDay
ORDER BY HourOfDay;

-- Q1c. User trends — sessions & watch time by province / gender / age band
SELECT Province, COUNT(*) AS sessions, ROUND(SUM(DurationSeconds)/3600,1) AS watch_hours
FROM brighttv.viewership_sast GROUP BY Province ORDER BY sessions DESC;

SELECT Gender, COUNT(*) AS sessions, ROUND(SUM(DurationSeconds)/3600,1) AS watch_hours
FROM brighttv.viewership_sast GROUP BY Gender ORDER BY sessions DESC;

SELECT
  CASE
    WHEN Age < 18 THEN '<18'
    WHEN Age BETWEEN 18 AND 24 THEN '18-24'
    WHEN Age BETWEEN 25 AND 34 THEN '25-34'
    WHEN Age BETWEEN 35 AND 44 THEN '35-44'
    WHEN Age BETWEEN 45 AND 54 THEN '45-54'
    ELSE '55+' END AS AgeBand,
  COUNT(*) AS sessions,
  ROUND(SUM(DurationSeconds)/3600,1) AS watch_hours
FROM brighttv.viewership_sast
GROUP BY 1 ORDER BY sessions DESC;

-- ------------------------------------------------------------
-- Q2. Factors influencing consumption — top channels overall
-- ------------------------------------------------------------
SELECT Channel, COUNT(*) AS sessions, ROUND(SUM(DurationSeconds)/3600,1) AS watch_hours
FROM brighttv.viewership_sast
GROUP BY Channel
ORDER BY sessions DESC
LIMIT 10;

-- ------------------------------------------------------------
-- Q3. What to recommend on the lowest-consumption day
-- Compare top channels on the lowest day vs. the highest day
-- ------------------------------------------------------------
SELECT Channel, COUNT(*) AS sessions
FROM brighttv.viewership_sast
WHERE DayOfWeek = 'Monday'          -- lowest-consumption day, see Q1a
GROUP BY Channel
ORDER BY sessions DESC
LIMIT 10;

SELECT Channel, COUNT(*) AS sessions
FROM brighttv.viewership_sast
WHERE DayOfWeek = 'Saturday'        -- highest-consumption day, see Q1a
GROUP BY Channel
ORDER BY sessions DESC
LIMIT 10;

-- ------------------------------------------------------------
-- Q4. Growth — reach: how many of our registered subscribers
-- actually generated a viewing session in this window?
-- ------------------------------------------------------------
SELECT
  (SELECT COUNT(DISTINCT UserID) FROM brighttv.viewership)      AS active_viewers,
  (SELECT COUNT(*) FROM brighttv.user_profiles)                 AS total_subscribers,
  ROUND(100.0 * (SELECT COUNT(DISTINCT UserID) FROM brighttv.viewership)
        / (SELECT COUNT(*) FROM brighttv.user_profiles), 1)     AS pct_active;
